var secondFile = () => { console.log('From secondFile'); };
secondFile();

